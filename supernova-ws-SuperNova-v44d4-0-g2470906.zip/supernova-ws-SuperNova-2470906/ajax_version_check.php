<?php

require_once('includes/init.' . substr(strrchr(__FILE__, '.'), 1));

\Common\Tools\VersionCheckerDeprecated::handleCall();
