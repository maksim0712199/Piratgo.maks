<?php

/**
 * This file is needed only for phpStorm hints constants from modules
 * This file is never included into project and no actual actions taken here
 */

return;

define('UNUSED_TEST_CONSTANT_REALLY_NEVER_USED', true);
