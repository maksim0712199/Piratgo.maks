<?php
/**
 * Created by Gorlum 08.01.2018 14:47
 */

namespace Core;

/**
 * Class Entity
 *
 * Represents base in-game entity
 *
 * @package Core
 */

class Entity {

  public function __construct() {
    // Abstract class - just to remember
  }

}
