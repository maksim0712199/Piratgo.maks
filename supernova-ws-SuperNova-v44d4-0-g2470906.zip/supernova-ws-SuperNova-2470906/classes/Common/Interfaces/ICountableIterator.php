<?php
/**
 * Created by Gorlum 19.10.2017 15:01
 */

namespace Common\Interfaces;


interface ICountableIterator extends \Iterator, \Countable {

}
