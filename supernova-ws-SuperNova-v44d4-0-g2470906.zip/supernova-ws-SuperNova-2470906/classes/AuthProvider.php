<?php

/**
 * Created by PhpStorm.
 * User: Gorlum
 * Date: 24.08.2015
 * Time: 6:00
 */
class AuthProvider {

}